
import streamlit as st
import speech_recognition as sr
import PyPDF2

st.set_page_config(page_title="Atendimento Fisioterapia com IA", layout="centered")
st.title("🤖 Atendimento com Inteligência Artificial - Fisioterapia")

# Reconhecimento de voz
st.subheader("🎙️ Captura de voz")
if st.button("Gravar relato do paciente"):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        st.info("Aguardando fala...")
        audio = recognizer.listen(source)
    try:
        texto = recognizer.recognize_google(audio, language="pt-BR")
        st.session_state.relato = texto
        st.success("Texto reconhecido com sucesso!")
    except sr.UnknownValueError:
        st.error("Não foi possível entender o áudio.")
    except sr.RequestError:
        st.error("Erro ao conectar com o serviço de reconhecimento.")

# Upload de PDF
st.subheader("📄 Extrair texto de PDF")
uploaded_file = st.file_uploader("Envie um arquivo PDF com o atendimento", type="pdf")
if uploaded_file is not None:
    try:
        pdf_reader = PyPDF2.PdfReader(uploaded_file)
        texto_pdf = ""
        for page in pdf_reader.pages:
            texto_pdf += page.extract_text()
        st.session_state.relato = texto_pdf
        st.success("Texto extraído do PDF com sucesso!")
    except Exception as e:
        st.error(f"Erro ao processar o PDF: {e}")

# Ficha do paciente
st.subheader("📋 Ficha do Paciente")
nome = st.text_input("Nome do Paciente")
idade = st.number_input("Idade", min_value=0, max_value=120, step=1)
sexo = st.selectbox("Sexo", ["Masculino", "Feminino", "Outro"])
relato = st.text_area("Relato do paciente", value=st.session_state.get("relato", ""), height=200)

if st.button("Salvar Atendimento"):
    st.success(f"Atendimento de {nome} salvo com sucesso!")
